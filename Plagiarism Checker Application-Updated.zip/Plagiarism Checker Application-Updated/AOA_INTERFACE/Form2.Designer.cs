﻿namespace AOA_INTERFACE
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TextBoxFilePath1 = new System.Windows.Forms.TextBox();
            this.TextBoxFilePath2 = new System.Windows.Forms.TextBox();
            this.LabelFilePath1 = new System.Windows.Forms.Label();
            this.LabelFilePath2 = new System.Windows.Forms.Label();
            this.LabelPalgiarismChecker = new System.Windows.Forms.Label();
            this.ButtonFileCheckPalgiarism = new System.Windows.Forms.Button();
            this.ButtonBack = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_SelectFile2 = new System.Windows.Forms.Button();
            this.btn_SelectFile1 = new System.Windows.Forms.Button();
            this.groupBox_FolderChecking = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.radio_btn_Files = new System.Windows.Forms.RadioButton();
            this.radio_btn_Folders = new System.Windows.Forms.RadioButton();
            this.groupBoxCppFiles = new System.Windows.Forms.GroupBox();
            this.btnSlctFleCpp2 = new System.Windows.Forms.Button();
            this.btnSlctFleCpp1 = new System.Windows.Forms.Button();
            this.textBoxcpp2 = new System.Windows.Forms.TextBox();
            this.textBoxcpp1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.radioButtonCpp = new System.Windows.Forms.RadioButton();
            this.buttonExit = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox_FolderChecking.SuspendLayout();
            this.groupBoxCppFiles.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // TextBoxFilePath1
            // 
            this.TextBoxFilePath1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxFilePath1.Location = new System.Drawing.Point(105, 25);
            this.TextBoxFilePath1.Name = "TextBoxFilePath1";
            this.TextBoxFilePath1.Size = new System.Drawing.Size(513, 23);
            this.TextBoxFilePath1.TabIndex = 0;
            this.TextBoxFilePath1.TextChanged += new System.EventHandler(this.TextBoxFilePath1_TextChanged);
            // 
            // TextBoxFilePath2
            // 
            this.TextBoxFilePath2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxFilePath2.Location = new System.Drawing.Point(105, 70);
            this.TextBoxFilePath2.Name = "TextBoxFilePath2";
            this.TextBoxFilePath2.Size = new System.Drawing.Size(513, 23);
            this.TextBoxFilePath2.TabIndex = 1;
            this.TextBoxFilePath2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // LabelFilePath1
            // 
            this.LabelFilePath1.AutoSize = true;
            this.LabelFilePath1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelFilePath1.Location = new System.Drawing.Point(15, 24);
            this.LabelFilePath1.Name = "LabelFilePath1";
            this.LabelFilePath1.Size = new System.Drawing.Size(84, 18);
            this.LabelFilePath1.TabIndex = 2;
            this.LabelFilePath1.Text = "FilePath 1";
            // 
            // LabelFilePath2
            // 
            this.LabelFilePath2.AutoSize = true;
            this.LabelFilePath2.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelFilePath2.Location = new System.Drawing.Point(15, 79);
            this.LabelFilePath2.Name = "LabelFilePath2";
            this.LabelFilePath2.Size = new System.Drawing.Size(84, 18);
            this.LabelFilePath2.TabIndex = 3;
            this.LabelFilePath2.Text = "FilePath 2";
            // 
            // LabelPalgiarismChecker
            // 
            this.LabelPalgiarismChecker.AutoSize = true;
            this.LabelPalgiarismChecker.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelPalgiarismChecker.Location = new System.Drawing.Point(268, 13);
            this.LabelPalgiarismChecker.Name = "LabelPalgiarismChecker";
            this.LabelPalgiarismChecker.Size = new System.Drawing.Size(325, 39);
            this.LabelPalgiarismChecker.TabIndex = 4;
            this.LabelPalgiarismChecker.Text = "Plagiarism Checker";
            // 
            // ButtonFileCheckPalgiarism
            // 
            this.ButtonFileCheckPalgiarism.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ButtonFileCheckPalgiarism.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonFileCheckPalgiarism.Location = new System.Drawing.Point(338, 470);
            this.ButtonFileCheckPalgiarism.Name = "ButtonFileCheckPalgiarism";
            this.ButtonFileCheckPalgiarism.Size = new System.Drawing.Size(189, 57);
            this.ButtonFileCheckPalgiarism.TabIndex = 5;
            this.ButtonFileCheckPalgiarism.Text = "Check Palagrism";
            this.ButtonFileCheckPalgiarism.UseVisualStyleBackColor = false;
            this.ButtonFileCheckPalgiarism.Click += new System.EventHandler(this.ButtonFileCheckPalgiarism_Click);
            // 
            // ButtonBack
            // 
            this.ButtonBack.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ButtonBack.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonBack.Location = new System.Drawing.Point(533, 470);
            this.ButtonBack.Name = "ButtonBack";
            this.ButtonBack.Size = new System.Drawing.Size(170, 56);
            this.ButtonBack.TabIndex = 6;
            this.ButtonBack.Text = "Back";
            this.ButtonBack.UseVisualStyleBackColor = false;
            this.ButtonBack.Click += new System.EventHandler(this.ButtonBack_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.groupBox1.Controls.Add(this.btn_SelectFile2);
            this.groupBox1.Controls.Add(this.TextBoxFilePath2);
            this.groupBox1.Controls.Add(this.btn_SelectFile1);
            this.groupBox1.Controls.Add(this.TextBoxFilePath1);
            this.groupBox1.Controls.Add(this.LabelFilePath1);
            this.groupBox1.Controls.Add(this.LabelFilePath2);
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(12, 111);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(781, 115);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "File Checking";
            // 
            // btn_SelectFile2
            // 
            this.btn_SelectFile2.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btn_SelectFile2.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SelectFile2.Location = new System.Drawing.Point(633, 61);
            this.btn_SelectFile2.Name = "btn_SelectFile2";
            this.btn_SelectFile2.Size = new System.Drawing.Size(101, 38);
            this.btn_SelectFile2.TabIndex = 12;
            this.btn_SelectFile2.Text = "Select File";
            this.btn_SelectFile2.UseVisualStyleBackColor = false;
            this.btn_SelectFile2.Click += new System.EventHandler(this.btn_SelectFile2_Click);
            // 
            // btn_SelectFile1
            // 
            this.btn_SelectFile1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btn_SelectFile1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SelectFile1.Location = new System.Drawing.Point(633, 18);
            this.btn_SelectFile1.Name = "btn_SelectFile1";
            this.btn_SelectFile1.Size = new System.Drawing.Size(101, 37);
            this.btn_SelectFile1.TabIndex = 11;
            this.btn_SelectFile1.Text = "Select File";
            this.btn_SelectFile1.UseVisualStyleBackColor = false;
            this.btn_SelectFile1.Click += new System.EventHandler(this.btn_SelectFile1_Click);
            // 
            // groupBox_FolderChecking
            // 
            this.groupBox_FolderChecking.Controls.Add(this.textBox1);
            this.groupBox_FolderChecking.Controls.Add(this.button1);
            this.groupBox_FolderChecking.Controls.Add(this.label1);
            this.groupBox_FolderChecking.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_FolderChecking.Location = new System.Drawing.Point(12, 244);
            this.groupBox_FolderChecking.Name = "groupBox_FolderChecking";
            this.groupBox_FolderChecking.Size = new System.Drawing.Size(781, 87);
            this.groupBox_FolderChecking.TabIndex = 8;
            this.groupBox_FolderChecking.TabStop = false;
            this.groupBox_FolderChecking.Text = "Folder Checking";
            this.groupBox_FolderChecking.Visible = false;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(81, 39);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(498, 23);
            this.textBox1.TabIndex = 2;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.button1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(606, 31);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(128, 36);
            this.button1.TabIndex = 1;
            this.button1.Text = "Select Folder";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Path";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // radio_btn_Files
            // 
            this.radio_btn_Files.AutoSize = true;
            this.radio_btn_Files.Checked = true;
            this.radio_btn_Files.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radio_btn_Files.Location = new System.Drawing.Point(166, 75);
            this.radio_btn_Files.Name = "radio_btn_Files";
            this.radio_btn_Files.Size = new System.Drawing.Size(107, 20);
            this.radio_btn_Files.TabIndex = 9;
            this.radio_btn_Files.TabStop = true;
            this.radio_btn_Files.Text = "File Checking";
            this.radio_btn_Files.UseVisualStyleBackColor = true;
            this.radio_btn_Files.CheckedChanged += new System.EventHandler(this.radio_btn_Files_CheckedChanged);
            // 
            // radio_btn_Folders
            // 
            this.radio_btn_Folders.AutoSize = true;
            this.radio_btn_Folders.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radio_btn_Folders.Location = new System.Drawing.Point(302, 75);
            this.radio_btn_Folders.Name = "radio_btn_Folders";
            this.radio_btn_Folders.Size = new System.Drawing.Size(126, 20);
            this.radio_btn_Folders.TabIndex = 10;
            this.radio_btn_Folders.Text = "Folder Checking";
            this.radio_btn_Folders.UseVisualStyleBackColor = true;
            this.radio_btn_Folders.CheckedChanged += new System.EventHandler(this.radio_btn_Folders_CheckedChanged);
            // 
            // groupBoxCppFiles
            // 
            this.groupBoxCppFiles.Controls.Add(this.btnSlctFleCpp2);
            this.groupBoxCppFiles.Controls.Add(this.btnSlctFleCpp1);
            this.groupBoxCppFiles.Controls.Add(this.textBoxcpp2);
            this.groupBoxCppFiles.Controls.Add(this.textBoxcpp1);
            this.groupBoxCppFiles.Controls.Add(this.label3);
            this.groupBoxCppFiles.Controls.Add(this.label2);
            this.groupBoxCppFiles.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxCppFiles.Location = new System.Drawing.Point(12, 347);
            this.groupBoxCppFiles.Name = "groupBoxCppFiles";
            this.groupBoxCppFiles.Size = new System.Drawing.Size(781, 100);
            this.groupBoxCppFiles.TabIndex = 11;
            this.groupBoxCppFiles.TabStop = false;
            this.groupBoxCppFiles.Text = "Check .cpp Files";
            this.groupBoxCppFiles.Visible = false;
            // 
            // btnSlctFleCpp2
            // 
            this.btnSlctFleCpp2.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnSlctFleCpp2.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSlctFleCpp2.Location = new System.Drawing.Point(633, 58);
            this.btnSlctFleCpp2.Name = "btnSlctFleCpp2";
            this.btnSlctFleCpp2.Size = new System.Drawing.Size(115, 33);
            this.btnSlctFleCpp2.TabIndex = 5;
            this.btnSlctFleCpp2.Text = "Select File";
            this.btnSlctFleCpp2.UseVisualStyleBackColor = false;
            this.btnSlctFleCpp2.Click += new System.EventHandler(this.btnSlctFleCpp2_Click);
            // 
            // btnSlctFleCpp1
            // 
            this.btnSlctFleCpp1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnSlctFleCpp1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSlctFleCpp1.Location = new System.Drawing.Point(633, 17);
            this.btnSlctFleCpp1.Name = "btnSlctFleCpp1";
            this.btnSlctFleCpp1.Size = new System.Drawing.Size(115, 35);
            this.btnSlctFleCpp1.TabIndex = 4;
            this.btnSlctFleCpp1.Text = "Select File";
            this.btnSlctFleCpp1.UseVisualStyleBackColor = false;
            this.btnSlctFleCpp1.Click += new System.EventHandler(this.btnSlctFleCpp1_Click);
            // 
            // textBoxcpp2
            // 
            this.textBoxcpp2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxcpp2.Location = new System.Drawing.Point(81, 61);
            this.textBoxcpp2.Name = "textBoxcpp2";
            this.textBoxcpp2.Size = new System.Drawing.Size(537, 23);
            this.textBoxcpp2.TabIndex = 3;
            // 
            // textBoxcpp1
            // 
            this.textBoxcpp1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxcpp1.Location = new System.Drawing.Point(81, 23);
            this.textBoxcpp1.Name = "textBoxcpp1";
            this.textBoxcpp1.Size = new System.Drawing.Size(537, 23);
            this.textBoxcpp1.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 19);
            this.label3.TabIndex = 1;
            this.label3.Text = "Path2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 19);
            this.label2.TabIndex = 0;
            this.label2.Text = "Path1";
            // 
            // radioButtonCpp
            // 
            this.radioButtonCpp.AutoSize = true;
            this.radioButtonCpp.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonCpp.Location = new System.Drawing.Point(462, 75);
            this.radioButtonCpp.Name = "radioButtonCpp";
            this.radioButtonCpp.Size = new System.Drawing.Size(138, 20);
            this.radioButtonCpp.TabIndex = 12;
            this.radioButtonCpp.Text = ".cpp File Checking";
            this.radioButtonCpp.UseVisualStyleBackColor = true;
            this.radioButtonCpp.CheckedChanged += new System.EventHandler(this.radioButtonCpp_CheckedChanged);
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonExit.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.Location = new System.Drawing.Point(709, 470);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(84, 56);
            this.buttonExit.TabIndex = 13;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::AOA_INTERFACE.Properties.Resources.@__2___Plagiarism_Checker_512_icon;
            this.pictureBox1.Location = new System.Drawing.Point(823, -9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(209, 289);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(1055, 540);
            this.ControlBox = false;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.radioButtonCpp);
            this.Controls.Add(this.groupBoxCppFiles);
            this.Controls.Add(this.radio_btn_Folders);
            this.Controls.Add(this.radio_btn_Files);
            this.Controls.Add(this.groupBox_FolderChecking);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.ButtonBack);
            this.Controls.Add(this.ButtonFileCheckPalgiarism);
            this.Controls.Add(this.LabelPalgiarismChecker);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form2";
            this.Text = "Form2";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox_FolderChecking.ResumeLayout(false);
            this.groupBox_FolderChecking.PerformLayout();
            this.groupBoxCppFiles.ResumeLayout(false);
            this.groupBoxCppFiles.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TextBoxFilePath1;
        private System.Windows.Forms.TextBox TextBoxFilePath2;
        private System.Windows.Forms.Label LabelFilePath1;
        private System.Windows.Forms.Label LabelFilePath2;
        private System.Windows.Forms.Label LabelPalgiarismChecker;
        private System.Windows.Forms.Button ButtonFileCheckPalgiarism;
        private System.Windows.Forms.Button ButtonBack;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox_FolderChecking;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radio_btn_Files;
        private System.Windows.Forms.RadioButton radio_btn_Folders;
        private System.Windows.Forms.Button btn_SelectFile1;
        private System.Windows.Forms.Button btn_SelectFile2;
        private System.Windows.Forms.GroupBox groupBoxCppFiles;
        private System.Windows.Forms.Button btnSlctFleCpp2;
        private System.Windows.Forms.Button btnSlctFleCpp1;
        private System.Windows.Forms.TextBox textBoxcpp2;
        private System.Windows.Forms.TextBox textBoxcpp1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton radioButtonCpp;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}